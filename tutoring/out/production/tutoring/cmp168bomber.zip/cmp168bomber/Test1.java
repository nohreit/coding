package cmp168bomber;

public class Test1 {

	public static void main(String[] args) {
		Minesweeper minesweep = new Minesweeper();
	}

}
