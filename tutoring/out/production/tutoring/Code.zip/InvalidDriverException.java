//package finalExam2020;



public class InvalidDriverException extends Exception{

	public InvalidDriverException(){
		
	}
	
	public InvalidDriverException(String message) {
		super(message);
	}
}
