package cmp168;

//package homework3;

public class Passenger {
    private String name;
    private int birthYear;
    private double weight;
    private char gender;
    private int numCarryOn;
    private double height;

    public Passenger() {
        name = "";
        birthYear = 1900;
        weight = 0.0;
        gender = 'u';
        numCarryOn = 0;

    }

    public Passenger(String name, int birthYear, double weight, char gender, int numCarryOn) {
        this.name = name;
        this.birthYear = birthYear;

        if (weight < 0) weight = -1; //weight is correct logic
        this.weight = weight;
        if (gender != 'f' && gender != 'm') gender = 'u';
        this.gender = gender;
        if (numCarryOn < 0) numCarryOn = 0;
        if (numCarryOn > 2) numCarryOn = 2;
        this.numCarryOn = numCarryOn;
    }

    public int calculateAge(int currentYear) {
        return (currentYear - this.birthYear) >= 0 ? currentYear - this.birthYear : -1;
    }

    public void gainWeight() {
        weight++;
    }

    public void gainWeight(double weight) {
        this.weight += weight;
        if (this.weight < 0) this.weight = 0;
    }


    public String getName() {
        return name;
    }

    public int getBirthYear() {
        return birthYear;
    }

    public double getWeight() {
        return weight;
    }

    public char getGender() {
        return gender;
    }

    public int getNumCarryOn() {
        return numCarryOn;
    }

    public double getHeight() {
        return height;
    }

    public boolean isFemale() {
        return this.getGender() == 'f';
    }

    public boolean isMale() {
        return this.getGender() == 'm';
    }

    public void loseWeight() {
        this.weight--;
        if (this.weight < 0) this.weight = 0;
    }

    public void loseWeight(double w) {
        this.weight -= w;
        if (this.weight < 0) this.weight = 0;
    }


    public void printDetails() {
        System.out.printf("Name: %20s| Year Of Birth: %4d| Weight: %10.2f| Gender: %c\n",
                this.name, this.birthYear, this.weight, this.gender);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    public void setWeight(double weight) {
        this.weight = (weight >= 0) ? weight : -1;
    }

    public void setGender(char gender) {
        this.gender = (gender != 'f' && gender != 'm') ? 'u' : gender;
    }

    public void setNumCarryOn(int numCarryOn) {
        if (numCarryOn < 0) numCarryOn = 0;
        if (numCarryOn > 2) numCarryOn = 2;
        this.numCarryOn = numCarryOn;
    }

    public void setHeight(double height) {
        this.height = (height >= 0) ? height : -1;
    }
}

