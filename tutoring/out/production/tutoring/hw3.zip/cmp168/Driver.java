package cmp168;

public class Driver {
    public static void main(String[] args) {
//        Passenger p1 = new Passenger();
//        Passenger p2 = new Passenger("Lara Croft", 1997, 150, 'f', 1);
//        Airplane a1 = new Airplane();
//        Airplane a2 = new Airplane("Jumanji");
//        Airplane a3 = new Airplane(20);
//        Airplane a4 = new Airplane("Amazonas", 30);
        Airplane a5 = new Airplane("Amazonas", 100);

        Passenger[] passengers = new Passenger[100];

//        a1.addPassenger(p1);
//        a1.addPassenger(p2);
//
//        pln("Name: "+a2.getAirplaneName()); // Jumanji
//        pln("passenger at the seat 1: "+ a1.getPassenger(0).getName());
//        pln("1st passenger: "+ a1.getFirstPassenger().getName());
//        pln("last passenger: "+ a1.getLastPassenger().getName());
//        pln("Number of passenger: "+ a1.getNumPassengers());
//        for(int i = 0; i < a4.getNumPassengers(); i++)
//            pln("Passenger ["+(i+1)+"]: " + a4.getPassengers()[0]);
//        a1.printAllDetails();
//        a2.printAllDetails();
//        a3.printAllDetails();
//        a4.printAllDetails();
//        pln("This passenger " + a1.removePassenger(0).getName() + " was kicked out of the airplane");
//        pln("passenger at the seat 1: "+ a1.getPassenger(0).getName());

        for (int i = 0; i < passengers.length; i++) {
            passengers[i] = new Passenger("Passenger" + i, 1920 + i, 175 - i, 'u', 1);
        }

        for (int i = 0; i < passengers.length; i++) {
            a5.addPassenger(passengers[i]);
        }

        a5.printAllDetails();


    }

    public static void pln(Object o) {
        System.out.println(o);
    }

    public static void p(Object o) {
        System.out.print(o);
    }
}
