package tutoring;

public class Airplane {
    private Passenger[] passengers;
    private String airplaneName;
    private int numPassengers;

    public Airplane() {
        this.passengers = new Passenger[100];
        this.numPassengers = 0;
        this.airplaneName = "";

    }

    public Airplane(String name) {
        this.passengers = new Passenger[100];
        this.numPassengers = 0;
        this.airplaneName = name;

    }

    public Airplane(int num) {
        if(num > 0) {
            this.passengers = new Passenger[num];
        }
        else {
            this.passengers = new Passenger[0];
        }
        this.numPassengers = 0;
        this.airplaneName = "";
    }

    public Airplane(String name, int num) {
        if(num > 0) {
            this.passengers = new Passenger[num];
        }
        else {
            this.passengers = new Passenger[0];
        }
        this.numPassengers = 0;
        this.airplaneName = name;
    }

    public void addPassenger(Passenger p) {
        if (numPassengers >= passengers.length) {
            resizePassengerArray();
        }
        passengers[numPassengers] = p;
        numPassengers++;
    }
    public void resizePassengerArray() {
        if(this.passengers.length == 0)
            this.passengers = new Passenger[1];
        else {
            Passenger[] temp = this.passengers;
            this.passengers = new Passenger[this.passengers.length*2];
            for(int i = 0; i<temp.length; i++) {
                this.passengers[i] = temp[i];
            }
        }
    }
    public String getAirplaneName() {
        return airplaneName;

    }

    public Passenger getPassenger(int index) {
        if( (index >= 0 && index < passengers.length) && this.passengers[index] != null) {
            return passengers[index];
        }
        return null;
    }

    public Passenger getFirstPassenger() {
        return passengers[0];
    }

    public Passenger getLastPassenger() {
        return passengers [numPassengers-1];
    }

    public void setAirplaneName(String airplaneName) {
        this.airplaneName = airplaneName;
    }

    public void printDetails() {
        System.out.printf("AirplaneName: %20s| Number of Passengers: %4d| Airplane Size: %4d\n ",
                this.airplaneName, this.numPassengers, this.passengers.length);
        for(int i = 0; i < this.numPassengers; i++) {
            System.out.printf("Name: %20s| Year Of Birth: %4d| Weight: %10.2f| Gender: %c\n",
                    this.getPassenger(i).getName(),
                    this.getPassenger(i).getBirthYear(),
                    this.getPassenger(i).getWeight(),
                    this.getPassenger(i).getGender());
        }
    }

    public Passenger removePassenger(int index) {
        if( (index >= 0 && index < passengers.length) && this.passengers[index] != null) {

            Passenger temp = passengers[index]; // Keeps the removed passenger for display

            for(int i = index; i < this.numPassengers; i++) { // This is to move back passengers that come after the deleted one
                if(this.passengers[i] != null)
                    passengers[i] = passengers [i + 1];
            }

            this.numPassengers--; // Decrement the number of passenger

            return temp;
        }

        // I will be back withing 10 to 15 mins.

        return null;
    }


    public double getTotalWeightOfAllPassengers() {
        double total = 0.0;
        for(int i = 0; i < numPassengers; i++) {
            total = total + passengers[i].getWeight();
        }
        return total;
    }

    public double getAverageWeightOfAllPassengers() {
        double total = 0.0;
        for(int i = 0; i < numPassengers; i++) {
            total = total + passengers[i].getWeight();
        }
        return total;
    }

    public void increaseWeightOfAllPassengers() {
        for(int i = 0; i < this.numPassengers; i++) {
            this.passengers[i].gainWeight();
        }
    }

    public void increaseWeightOfAllPassengers(double value) {
        for(int i = 0; i < this.numPassengers; i++) {
            this.passengers[i].gainWeight();
        }
    }

    public int getNumbersOfPassengersAboveWeight(double weight) {
        int count = 0;
        for(int i = 0; i < this.numPassengers; i++) {
            if(this.passengers[i].getWeight() > weight)
                count++;

        }
        return count;
    }
}


