package tutoring;

public class Driver {
    public static void main (String [] args){
        Passenger p1 = new Passenger();
        Passenger p2 = new Passenger("Lara Croft", 1997, 150, 'f', 1);
        Airplane a1 = new Airplane();
        Airplane a2 = new Airplane("Jumanji");
        Airplane a3 = new Airplane(20);
        Airplane a4 = new Airplane("Amazonas", 30);

        a1.addPassenger(p1);
        a1.addPassenger(p2);

        pln("Name: "+a2.getAirplaneName()); // Jumanji
        pln("passenger at the seat 1: "+ a1.getPassenger(0).getName());
        pln("1st passenger: "+ a1.getFirstPassenger().getName());
        pln("last passenger: "+ a1.getLastPassenger().getName());
        a1.printDetails();
        a2.printDetails();
        a3.printDetails();
        a4.printDetails();
        pln("This passenger " + a1.removePassenger(0).getName() + " was kicked out of the airplane");
        pln("passenger at the seat 1: "+ a1.getPassenger(0).getName());

    }

    public static void pln(Object o){ System.out.println(o);}
    public static void p(Object o){ System.out.print(o);}
}
