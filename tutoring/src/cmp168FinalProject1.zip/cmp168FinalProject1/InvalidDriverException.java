package cmp168FinalProject1;

public class InvalidDriverException extends Exception{

	public InvalidDriverException(){
		
	}
	
	public InvalidDriverException(String message) {
		super(message);
	}
}
