package cmp168FinalProject1;

public interface Announcements {

	public String departure();
	
	public String arrival();
	
	public String doNotDisturbTheDriver();
}

