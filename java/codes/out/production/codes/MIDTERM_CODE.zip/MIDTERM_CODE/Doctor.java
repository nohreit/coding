//package MIDTERM_CODE;

   public class Doctor implements SeesPatients{

	private static int numDoctors=0; //increment inside the constructor
	private String name;
	private int licenseNumber;
	private Patient[] patients;
	private int numOfPatients;
	
	public Doctor(String name) {
		this.name= name;
		numDoctors++;
		licenseNumber=numDoctors;
		 patients= new Patient[MAX_PATIENTS];
		 numOfPatients=0;
	}
	
	public static int getNumDoctors() {
		return numDoctors;
	}

	public int getLicenseNumber() {
		return licenseNumber;
	}
	
	public String getName() {
		return name;
	}
	
	public int getNumberOfPatients() {
		return this.numOfPatients;
	}
	
	@Override
	public String toString() {
		String s= String.format("Doctor= name= %20s | license number= %06d | %s", name, licenseNumber, getPatientsAsString());
		return s;
	}
	
	@Override
	public boolean equals(Object d) {
		if(d instanceof Doctor){
			Doctor otherD = (Doctor)d;
			if(this.name == otherD.name) {
				if(this.getNumberOfPatients() == otherD.getNumberOfPatients()) {
					return true;
				}
			 }
		
	    } return false;
    }
	
	public int compareTo(Doctor d) {
		Doctor oDoctor= (Doctor)d;
		int comp=0;
		if(this.getNumberOfPatients() > oDoctor.getNumberOfPatients()) {
			comp=1;
		} 
		else if(this.getNumberOfPatients() < oDoctor.getNumberOfPatients()) {
			comp=-1;
		}
		return comp;
	}

	@Override
	public void addPatient(Patient p) throws PatientException {
		if(this.numOfPatients != MAX_PATIENTS) {
			//for(int i=0; i<patients.length; i++) {
		patients[numOfPatients++]= p;
			//}
		} else {
			throw new PatientException("Cannot add more patients");
		}
	}

	@Override
	public Patient[] getPatients() {
		return patients;
	}

	@Override
	public String getPatientsAsString() {
		String s= "patients= ";
		for(int i=0; i<this.getNumberOfPatients(); i++) {
			s+= patients[i].toString()+ (i != (this.numOfPatients -1) ? ", " : "");
		}
		return s;
	}

	@Override
	//fix
	public boolean isPatient(Patient p) {
		boolean found= false;
		int i=0;
		while(!found && i<numOfPatients) {
			if( patients[i].equals(p)){
				found=true;
			}
				i++;
		}
		return found;
	}
	
}
