use trulia_real_estate;

-- select * from ListingAgent; 

-- select * from User;





